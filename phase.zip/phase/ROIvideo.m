clc
clear

%-------------------load the video----------------
 vid = VideoReader('speak.avi');
 vidHeight = vid.Height;
 vidWidth = vid.Width;
 nChannels = 3;
 fr = vid.FrameRate;
 len = vid.NumberOfFrames;
 temp = struct('cdata', zeros(vidHeight, vidWidth, nChannels, 'uint8'), 'colormap', []); 
 startIndex = 1;   
 endIndex =len;    
  
%-------------------select the ROI---------------- 
 firImag = read(vid, 1);
 figure; imshow(firImag);
 face_xy = imrect;% select ROI by the mouse
 pos = getPosition(face_xy);% pos(x,y, ROI width, ROI height), where (x,y) is the location of the upper left point of ROI rectangle
 pos=round(pos);  
     
%________________________Phase_________________________________
window=5; % average pooling size
tem_phase=zeros(floor(pos(4)/window),floor(pos(3)/window),endIndex-startIndex+1);
for i=startIndex:1:endIndex
       temp.cdata = read(vid, i);
       [rgbframe,~] = frame2im(temp);
       rgbframe = im2double(rgbframe);      
       fre=fft2(rgbframe); %Fourier transform for image
       fre_nor=fre./abs(fre); %remove amplitude information and remain phase information
       tem=ifft2(fre_nor); % here we get the phase of the i-th frame
       for mm=1:floor(pos(4)/window)
           for nn=1:floor(pos(3)/window)
             tem_phase(mm,nn,i)=mean(mean(tem(pos(2)+(mm-1)*window:pos(2)+mm*window,pos(1)+(nn-1)*window:pos(1)+nn*window))); % local average pooling for the i-th phase map
           end
       end
end    

%________________________Phase Difference_________________________________
tem_phase_diff=-abs(diff(tem_phase,1,3)); % 1��indicates compute the difference of adjacent frames��3��indicates time axis
tem_phase_diff=tem_phase_diff-min(min(min(tem_phase_diff)));
tem_phase_diff=tem_phase_diff/max(max(max(tem_phase_diff)));%Normalization (it is better than what we introduce in JBHI paper)

%______________construct phase difference video--------------------
aviobj=VideoWriter('speak_phase.avi');
aviobj.FrameRate = 30;
open(aviobj)
mean_mark=zeros(1,len-d);
for i=1:len-d
    frame=tem_phase_diff(:,:,i);
    mean_mark(i)=mean(mean(frame));
    writeVideo(aviobj,frame);
end
close(aviobj)

