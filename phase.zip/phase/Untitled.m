%% load images
ima1=imread('1.bmp');
ima1 = im2double(ima1);  
ima2=imread('2.bmp');
ima2 = im2double(ima2); 

%% compute phase maps
fre1=fft2(ima1(:,:,2));
fre_nor1=fre1./abs(fre1);
tem1=ifft2(fre_nor1);

fre2=fft2(ima2(:,:,2));
fre_nor2=fre2./abs(fre2);
tem2=ifft2(fre_nor2);

%% compute phase difference & normalization
tem_phase_diff=-abs(tem1-tem2); %there is a minus sign
tem_phase_diff=tem_phase_diff-min(min(tem_phase_diff));
tem_phase_diff=tem_phase_diff/max(max(tem_phase_diff));




