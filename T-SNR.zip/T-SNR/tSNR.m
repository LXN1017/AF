load('mapData.mat');
map_out = compute_mapping(L2,'tSNE',3);
load('sample_shuffle.mat');
x_train=reshape(sample_shuffle,size(sample_shuffle,1),150);
map_in = compute_mapping(x_train,'tSNE',3);
load('label_shuffle.mat')

load('prediction.mat')
for i=1:size(prediction,1)
if prediction(i)<0.5
    prediction_onehot(i,:)=0;
else
    prediction_onehot(i,:)=1;
end
end
error=prediction_onehot-double(label_shuffle);
loc1=find(error==1);
loc2=find(error==-1);

a = find(label_shuffle==1);b = find(label_shuffle==0);
figure;plot(map_in(a,1),map_in(a,2),'r');hold on; plot(map_in(b,1),map_in(b,2),'g');

c = find(label_shuffle==1);d = find(label_shuffle==0);
figure;plot(map_out(c,1),map_out(c,2),'r');hold on; plot(map_out(d,1),map_out(d,2),'g');plot(map_out(loc1,1),map_out(loc1,2));plot(map_out(loc2,1),map_out(loc2,2))

